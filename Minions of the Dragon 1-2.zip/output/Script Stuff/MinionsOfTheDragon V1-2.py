import sys
import time
import random
import pickle

run, menu, play, rules, key, standing, buy, speak, boss = True, True, False, False, False, True, False, \
    False, False

HP, HPMAX, ATK, pot, elix, gold, x, y, MP, MPMAX, shop_level = 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1

name, job, spatk = None, None, None

map = [["shop", "mayor", "bridge", "plains", "forest", "mountain", "cave"],
       ["bridge", "bridge", "forest", "forest", "forest", "hills", "mountain"],
       ["forest", "fields", "forest", "plains", "hills", "forest", "hills"],
       ["plains", "plains", "plains", "fields", "plains", "hills", "mountain"],
       ["plains", "fields", "fields", "plains", "hills", "mountain", "mountain"]]
y_len, x_len = len(map) - 1, len(map[0]) - 1

biom = {"plains": {"t": "PLAINS", "e": True},
        "forest": {"t": "WOODS", "e": True},
        "fields": {"t": "FIELDS", "e": True},
        "bridge": {"t": "BRIDGE", "e": False},
        "town": {"t": "TOWN CENTRE", "e": False},
        "shop": {"t": "SHOP", "e": False},
        "mayor": {"t": "MAYOR", "e": False},
        "cave": {"t": "CAVE", "e": False},
        "mountain": {"t": "MOUNTAIN", "e": True},
        "hills": {"t": "HILLS", "e": True}}

e_list = ["Goblin", "Orc", "Slime", "Dragon"]

mobs = {"Goblin": {"hp": 5, "at": 1, "g": 5}, "Orc": {"hp": 15, "at": 3, "g": 15},
        "Slime": {"hp": 10, "at": 2, "g": 10}, "Dragon": {"hp": 1000, "at": 10, "g": 100}}


def typewriter(text):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.05)
        if char in ["! ", ". ", "? ", len(text) - 1]:
            typewriter("\n")
        time.sleep(0.01)


def save():
    global name, job, HP, ATK, pot, elix, gold, x, y, key, HPMAX, MP, MPMAX, spatk, shop_level

    data = name, job, HP, ATK, pot, elix, gold, x, y, key, HPMAX, MP, MPMAX, spatk, shop_level

    with open("load.dat", "wb") as file:
        pickle.dump(data, file)


def load():
    global name, job, HP, ATK, pot, elix, gold, x, y, key, HPMAX, MP, MPMAX, spatk, shop_level, play, standing, menu
    with open('load.dat', 'rb') as file:
        name, job, HP, ATK, pot, elix, gold, x, y, key, HPMAX, MP, MPMAX, spatk, shop_level = pickle.load(file)
        standing = True
        play = True
        menu = False


def heal(amount):
    global HP, name, HPMAX, shop_level
    HP = min(HP + amount + 20 * shop_level, HPMAX)
    typewriter(f"{name}'s HP refilled to {str(HP)}!\n")


def mana(amount):
    global MP, MPMAX, name, shop_level
    MP = min(MP + amount + 20 * shop_level, MPMAX)
    typewriter(f"{name}'s MP refilled to {MP}!\n")


def battle():
    global HP, MP, pot, elix, gold, biom, boss
    enemy = "Dragon" if boss else random.choice(["Goblin", "Orc", "Slime"])
    enemy_stats = mobs[enemy]  # Get enemy stats from mobs dictionary
    hp, hpmax, atk, g = enemy_stats["hp"], enemy_stats["hp"], enemy_stats["at"], enemy_stats["g"]

    while HP > 0 and hp > 0:


        typewriter(f"Defeat the {enemy}!\n")
        typewriter(f"{enemy}'s HP: {hp}/{hpmax}\n")
        typewriter(f"{name}'s HP: {HP}/{HPMAX}\n")
        typewriter(f"{name}'s MP: {MP}/{MPMAX}\n")
        typewriter(f"POTIONS: {pot}\n")
        typewriter(f"ELIXIRS: {elix}\n")

        typewriter("1 - ATTACK\n")
        if MP > 9:
            typewriter("2 - SPECIAL ATTACK\n")
        if pot > 0:
            typewriter(f"3 - USE POTION ({10+20*shop_level}HP)\n")
        if elix > 0:
            typewriter(f"4 - USE ELIXIR ({10+20*shop_level}MP)\n")


        choice = input("# ")

        if choice == "1":
            hp -= ATK
            typewriter(f"{name} dealt {ATK} damage to the {enemy}.\n")
            if hp > 0:
                HP -= atk
                typewriter(f"{enemy} dealt {atk} damage to {name}.\n")
            input("# ")

        elif choice == "2":
            if MP > 9:
                MP -= 10
                if job == "Mage":
                    damage = ATK * 3
                    hp -= damage
                    typewriter(f"{name} used {spatk}! The enemy took {damage} damage!\n")
                    HP -= atk
                    typewriter(f"{enemy} dealt {atk} damage to {name}.\n")
                elif job == "Rogue":
                    if hp == hpmax:
                        damage = ATK * 4
                        hp -= damage
                        typewriter(f"{name} used {spatk}! The enemy took {damage} damage!\n")
                        HP -= atk
                        typewriter(f"{enemy} dealt {atk} damage to {name}.\n")
                    elif hp < hpmax:
                        typewriter("The enemy sees you!")
                elif job == "Warrior":
                    damage = ATK * 2
                    hp -= damage
                    typewriter(f"{name} used {spatk}! The enemy took {damage} damage!\n")
                    HP -= atk
                    typewriter(f"{enemy} dealt {atk} damage to {name}.\n")
            else:
                typewriter("Not enough mana!\n")

        elif choice == "3":
            if pot > 0:
                pot -= 1
                heal(10)
                HP -= atk
                typewriter(f"{enemy} dealt {atk} damage to {name}.\n")
            else:
                typewriter("No potions!\n")
            input("# ")

        elif choice == "4":
            if elix > 0:
                elix -= 1
                mana(10)
                HP -= atk
                typewriter(f"{enemy} dealt {atk} damage to {name}.\n")
            else:
                typewriter("No elixirs!\n")
            input("# ")

    if HP <= 0:
        typewriter(f"{enemy} defeated {name}...\n")

        typewriter("GAME OVER\n")
        input("# ")

    if hp <= 0:
        enemy_death(enemy, g)


def enemy_death(enemy, g):
    global boss, gold, pot, standing
    typewriter(f"{name} defeated the {enemy}!\n")

    gold += g
    typewriter(f"You've found {g} gold!\n")
    if random.randint(0, 100) < 30:
        pot += 1
        typewriter("You've found a potion!\n")
    if enemy == "Dragon":

        typewriter("Congratulations, you've finished the game! ...for now. Come back later for updates!\n")
        boss = False
    standing = True
    input("# ")


def shop():
    global buy, gold, pot, elix, ATK, shop_level, HPMAX, MPMAX

    while buy:
        typewriter("Welcome to the shop!\n")
        typewriter(f"GOLD: {str(gold)}" + "\n")
        typewriter(f"POTIONS: {str(pot)}" + "\n")
        typewriter(f"ELIXIRS: {str(elix)}" + "\n")
        typewriter(f"ATK: {str(ATK)}" + "\n")
        typewriter("Would you like to 1: buy, 2: upgrade, or 3: leave?\n")
        choice = input("# ")

        if choice == "1":
            typewriter(f"1 - BUY POTION ({10+20*shop_level}HP) - 5 GOLD\n")
            typewriter(f"2 - BUY ELIXIR ({10+20*shop_level}MP) - 8 GOLD\n")
            typewriter("3 - LEAVE\n")
            choice0 = input("# ")
            if choice0 == "1":
                if gold >= 5:
                    pot += 1
                    gold -= 5
                    typewriter("You've bought a potion!\n")
                else:
                    typewriter("Not enough gold!\n")
                input("# ")
            elif choice0 == "2":
                if gold >= 8:
                    elix += 1
                    gold -= 8
                    typewriter("You've bought an elixir!\n")
                else:
                    typewriter("Not enough gold!\n")
                input("# ")
            elif choice0 == "3":
                buy = False
        elif choice == "2":
            typewriter("What would you like to upgrade?\n")
            typewriter("1 - UPGRADE WEAPON (+1 ATK) - 10 GOLD\n")
            typewriter("2 - UPGRADE SHIELD (+10 MAX HP) - 15 GOLD\n")
            typewriter("3 - UPGRADE HELM (+10 MAX MP) - 20 GOLD\n")
            typewriter("4 - UPGRADE SHOP (+20 MP FROM ELIXIRS/HP FROM POTIONS) - 25 GOLD\n")
            typewriter("5 - LEAVE\n")
            choice0 = input("# ")
            if choice0 == "1":
                if gold >= 10:
                    ATK += 1
                    gold -= 10
                    typewriter("You've upgraded your weapon!\n")
                else:
                    typewriter("Not enough gold!\n")
            elif choice0 == "2":
                if gold >= 15:
                    HPMAX += 10
                    gold -= 15
                    typewriter("You've upgraded your shield!\n")
                else:
                    typewriter("Not enough gold!\n")
            elif choice0 == "3":
                if gold >= 20:
                    MPMAX += 10
                    gold -= 20
                    typewriter("You've upgraded your helm!\n")
                else:
                    typewriter("Not enough gold!\n")
            elif choice0 == "4":
                if gold >= 25:
                    shop_level += 1
                    gold -= 25
                    typewriter("You've upgraded the shop!\n")
            elif choice0 == "5":
                buy = False
        elif choice == "3":
            buy = False


def mayor():
    global speak, key

    while speak:


        typewriter(f"Hello there, {name}" + "!\n")
        if ATK >= 10 and MPMAX >= 100 and HPMAX >= 100:
            typewriter("You might want to take on the dragon now! Take this key but be careful with the beast!\n")
            key = True
        else:
            typewriter("You're not strong enough to face the dragon yet! Keep practicing and come back later!\n")
            key = False



        typewriter("1 - LEAVE\n")
        choice = input("# ")

        if choice == "1":
            speak = False


def cave():
    global boss, key

    while boss:


        typewriter("Here lies the cave of the dragon. What will you do?\n")

        if key:
            typewriter("1 - USE KEY\n")
            typewriter("2 - TURN BACK\n")


        choice = input("# ")

        if choice == "1":
            if key:
                battle()
        elif choice == "2":
            boss = False


def main():
    global run, menu, play, rules, key, standing, buy, speak, boss, job, spatk, HP, HPMAX, MP, MPMAX, ATK, name,\
        y, x, pot, elix, gold, shop_level

    run, menu, play, rules, key, standing, buy, speak, boss, fight, job, spatk, HP, HPMAX, MP, MPMAX, ATK, name, \
        y, x, pot, elix, gold, shop_level = True, True, False, False, False, True, False, False, False, False, None,\
        None, 0, 0, 0, 0, 0, None, 0, 0, 0, 0, 0, 1

    while run:
        while menu:

            typewriter("Welcome to Minions of the Dragon! What would you like to do?\n")
            typewriter("1: NEW GAME\n")
            typewriter("2: LOAD GAME\n")
            typewriter("3: HOW TO PLAY\n")
            choice = input("# ")
            if choice == "1":
                name = str(input("# What's your name, hero? "))
                job = input(
                    "What's your job? Press the number keys for the job you want. (1: Warrior, 2: Rogue, 3: Mage)")
                if job == '1':
                    job, spatk, HP, HPMAX, MP, MPMAX, ATK = "Warrior", "Critical Strike", 60, 60, 40, 40, 2
                elif job == '2':
                    job, spatk, HP, HPMAX, MP, MPMAX, ATK = "Rogue", "Sneak Attack", 50, 50, 50, 50, 3
                elif job == '3':
                    job, spatk, HP, HPMAX, MP, MPMAX, ATK = "Mage", "Fireball", 40, 40, 60, 60, 1
                standing = True
                play = True
                menu = False
            elif choice == "2":
                load()
            elif choice == "3":
                with open("How_to_Play.txt") as f:
                    typewriter(f.read())

        while play and not standing and biom[map[y][x]]["e"]:
            battle()
        while play and not standing and not biom[map[y][x]]["e"]:
            save()

            typewriter("LOCATION: " + biom[map[y][x]]["t"] + "\n")

            typewriter(f"NAME: {name}" + "\n")
            typewriter(f"HP: {str(HP)}/{str(HPMAX)}" + "\n")
            typewriter(f"MP: {str(MP)}/{str(MPMAX)}" + "\n")
            typewriter(f"JOB: {job}" + "\n")
            typewriter(f"ATK: {str(ATK)}" + "\n")
            typewriter(f"POTIONS: {str(pot)}" + "\n")
            typewriter(f"ELIXIRS: {str(elix)}" + "\n")
            typewriter(f"GOLD: {gold}\n")
            typewriter(f"COORD: {str(x)},{str(y)}" + "\n")

            typewriter("0 - SAVE AND QUIT""\n")
            if y > 0:
                typewriter("1 - NORTH""\n")
            if x < x_len:
                typewriter("2 - EAST""\n")
            if y < y_len:
                typewriter("3 - SOUTH""\n")
            if x > 0:
                typewriter("4 - WEST""\n")
            if pot > 0:
                typewriter(f"5 - USE POTION ({10+20*shop_level}HP)""\n")
            if elix > 0:
                typewriter(f"6 - USE ELIXIR ({10+20*shop_level}MP)""\n")
            if map[y][x] in ["shop", "mayor", "cave"]:
                typewriter("7 - ENTER""\n")

            dest = input("# ")

            if dest == "0":
                play = False
                menu = True
                save()
            elif dest == "1" and y > 0:
                y -= 1
                standing = False
            elif dest == "2" and x < x_len:
                x += 1
                standing = False
            elif dest == "3" and y < y_len:
                y += 1
                standing = False
            elif dest == "4" and x > 0:
                x -= 1
                standing = False
            elif dest == "5":
                if pot > 0:
                    pot -= 1
                    heal(10)
                else:
                    typewriter("No potions!")
                input("# ")
                standing = True
            elif dest == "6":
                if elix > 0:
                    elix -= 1
                    mana(10)
                else:
                    typewriter("No elixirs!")
                input("# ")
                standing = True
            elif dest == "7":
                if map[y][x] == "shop":
                    buy = True
                    shop()
                if map[y][x] == "mayor":
                    speak = True
                    mayor()
                if map[y][x] == "cave":
                    boss = True
                    cave()
            else:
                standing = True
        while play and standing:
            save()

            typewriter("LOCATION: " + biom[map[y][x]]["t"] + "\n")

            typewriter(f"NAME: {name}" + "\n")
            typewriter(f"HP: {str(HP)}/{str(HPMAX)}" + "\n")
            typewriter(f"MP: {str(MP)}/{str(MPMAX)}" + "\n")
            typewriter(f"JOB: {job}" + "\n")
            typewriter(f"ATK: {str(ATK)}" + "\n")
            typewriter(f"POTIONS: {str(pot)}" + "\n")
            typewriter(f"ELIXIRS: {str(elix)}" + "\n")
            typewriter(f"GOLD: {gold}\n")
            typewriter(f"COORD: {str(x)},{str(y)}" + "\n")


            typewriter("0 - SAVE AND QUIT""\n")
            if y > 0:
                typewriter("1 - NORTH""\n")
            if x < x_len:
                typewriter("2 - EAST""\n")
            if y < y_len:
                typewriter("3 - SOUTH""\n")
            if x > 0:
                typewriter("4 - WEST""\n")
            if pot > 0:
                typewriter(f"5 - USE POTION ({10+20*shop_level}HP)""\n")
            if elix > 0:
                typewriter(f"6 - USE ELIXIR ({10+20*shop_level}MP)""\n")
            if map[y][x] in ["shop", "mayor", "cave"]:
                typewriter("7 - ENTER""\n")


            dest = input("# ")

            if dest == "0":
                play = False
                menu = True
                save()
            elif dest == "1" and y > 0:
                y -= 1
                standing = False
            elif dest == "2" and x < x_len:
                x += 1
                standing = False
            elif dest == "3" and y < y_len:
                y += 1
                standing = False
            elif dest == "4" and x > 0:
                x -= 1
                standing = False
            elif dest == "5":
                if pot > 0:
                    pot -= 1
                    heal(10)
                else:
                    typewriter("No potions!")
                input("# ")
                standing = True
            elif dest == "6":
                if elix > 0:
                    elix -= 1
                    mana(10)
                else:
                    typewriter("No elixirs!")
                input("# ")
                standing = True
            elif dest == "7":
                if map[y][x] == "shop":
                    buy = True
                    shop()
                if map[y][x] == "mayor":
                    speak = True
                    mayor()
                if map[y][x] == "cave":
                    boss = True
                    cave()
            else:
                standing = True


main()
