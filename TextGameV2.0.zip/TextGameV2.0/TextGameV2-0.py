import os
import sys
import random
import easygui

actions = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'}

#  x = 0       x = 1       x = 2       x = 3       x = 4       x = 5          x = 6
map = [["town", "mayor", "bridge", "plains", "forest", "mountain", "cave"],  # y = 0
       ["shop", "forest", "forest", "forest", "forest", "hills", "mountain"],  # y = 1
       ["bridge", "fields", "plains", "hills", "forest", "hills", "hills"],  # y = 2
       ["plains", "fields", "plains", "hills", "forest", "hills", "mountain"],  # y = 3
       ["plains", "fields", "fields", "plains", "hills", "mountain", "mountain"]]  # y = 4)

y_len = len(map) - 1
x_len = len(map[0]) - 1

biom = {
    "plains": {
        "t": "PLAINS",
        "e": True},
    "forest": {
        "t": "WOODS",
        "e": True},
    "fields": {
        "t": "FIELDS",
        "e": False},
    "bridge": {
        "t": "BRIDGE",
        "e": True},
    "town": {
        "t": "TOWN CENTRE",
        "e": False},
    "shop": {
        "t": "SHOP",
        "e": False},
    "mayor": {
        "t": "MAYOR",
        "e": False},
    "cave": {
        "t": "CAVE",
        "e": False},
    "mountain": {
        "t": "MOUNTAIN",
        "e": True},
    "hills": {
        "t": "HILLS",
        "e": True,
    }
}
title = "TextRPG 2.0"
e_list = ["Goblin", "Orc", "Slime", "Harpy", "Minotaur", "Dragon's Mate"]
x = 0
y = 0
run = True
name = "name"
level = 1
job = "job"
ability = "ability"
HP = 0
MP = 0
HPMAX = 0
MPMAX = 0
ATK = 0
TATK = 0
pot = 1
elix = 1
quest_minotaurs = 0
quest_harpies = 0
quest_enemy = 0
quest_goblins = 0
quest_orcs = 0
quest_slimes = 0
keymaterial = 0
keymold = 0
keyenchant = 0
boss = False
gold = 0


def map_menu():
    print('  #x = 0       x = 1       x = 2       x = 3       x = 4       x = 5          x = 6')
    print('[["town"      "mayor"     "bridge"    "plains"    "forest"   "mountain"       "cave"]      y = 0')
    print('["shop",     "forest",    "forest",   "forest",   "forest",   "hills",       "mountain"],  y = 1')
    print('["bridge",   "fields",    "plains",   "hills",    "forest",   "hills",        "hills"  ],  y = 2')
    print('["plains"   ,"fields",    "plains",    "hills",   "forest"  , "hills",       "mountain"],  y = 3')
    print('["plains",   "fields",    "fields",    "plains",   "hills",  "mountain",     "mountain"]   y = 4')


def clear():
    os.system("cls")


def draw():
    print("xX--------------------xX")


def mana(amount):
    global name, MPMAX, MP, level, map, biom, y_len, x_len, e_list
    if MP + amount < MPMAX * level:
        MP += amount * level
    else:
        MP = MPMAX
    print(name + "'s MP refilled to " + str(MP) + "!")


def heal(amount):
    global HP, HPMAX, level, name, map, biom, y_len, x_len, e_list
    if HP + amount < HPMAX * level:
        HP += amount * level
    elif HP + amount >= HPMAX * level:
        HP = HPMAX
    print(name + "'s HP refilled to " + str(HP) + "!")


def battle():
    global map, biom, y_len, x_len, e_list, HP, ATK, TATK, keymaterial, boss, pot, elix, quest_enemy, quest_orcs, \
        quest_harpies, quest_slimes, quest_goblins, quest_minotaurs, HP, MP, HPMAX, MPMAX, job, ability, level, \
        keyenchant, name, gold
    fight = True
    if not boss:
        if quest_enemy < 2:
            enemy = "Goblin"
            hp = 15 * level
            at = 3 * level
            go = 8 * level
        elif quest_enemy == 2 and quest_goblins < 4:
            enemy = "Goblin"
            hp = 15 * level
            at = 3 * level
            go = 8 * level
        elif quest_goblins == 4 and quest_orcs < 2:
            enemy = "Orc"
            hp = 35 * level
            at = 5 * level
            go = 12 * level
        elif quest_orcs == 2 and quest_slimes < 4:
            enemy = "Slime"
            hp = 30 * level
            at = 2 * level
            go = 12 * level
        elif quest_slimes == 4 and quest_harpies < 2:
            enemy = "Harpy"
            hp = 45 * level
            at = 6 * level
            go = 16 * level
        elif quest_harpies == 2 and not endgame:
            enemy = "Minotaur"
            hp = 50 * level
            at = 8 * level
            go = 18 * level
        elif endgame:
            enemy = rand(e_list)
            if enemy == "Goblin":
                hp = 15 * level
                at = 3 * level
                go = 8 * level
            elif enemy == "Orc":
                hp = 35 * level
                at = 5 * level
                go = 12 * level
            elif enemy == "Slime":
                hp = 30 * level
                at = 2 * level
                go = 12 * level
            elif enemy == "Harpy":
                hp = 45 * level
                at = 6 * level
                go = 16 * level
            elif enemy == "Minotaur":
                hp = 50 * level
                at = 8 * level
                go = 18 * level
            elif enemy == "Dragon's Mate":
                hp = 250 * level
                at = 15 * level
                go = 100 * level
    else:
        enemy = "Dragon"
        hp = 250 * level
        at = 15 * level
        go = 100 * level
    hpmax = hp
    r = 0
    totem = 0
    while fight:
        clear()
        draw()
        print("Defeat the " + enemy + "!")
        draw()
        print(enemy + "'s HP: " + str(hp) + "/" + str(hpmax * level))
        print(enemy + "'s LEVEL: " + str(level))
        print(name + "'s HP: " + str(HP) + "/" + str(HPMAX * level))
        print(name + "'s MP: " + str(MP) + "/" + str(MPMAX * level))
        print("POTIONS: " + str(pot))
        print("ELIXIR: " + str(elix))
        draw()
        if job == "Shaman":
            print("1 - Skip Turn")
        elif job == "Warrior" or job == "Warlock" or job == "Mage" or job == "Rogue":
            print("1 - ATTACK")
        print("2 - ABILITY")
        if pot > 0:
            print("3 - USE POTION " + str(20 * level) + "HP")
        if elix > 0:
            print("4 - USE ELIXIR " + str(20 * level) + "MP")
        draw()
        r += 1
        choice_battle = input()
        clear()
        if choice_battle == "1":
            clear()
            if job == "Shaman":
                print("Turn skipped!")
            elif job == "Warrior" or job == "Warlock" or job == "Mage" or job == "Rogue":
                hp -= ATK * level
                print(name + " dealt " + str(ATK * level) + " damage to the " + enemy + ".")
        elif choice_battle == "2":
            clear()
            if job == "Warrior":
                if MP >= 5:
                    hp -= ATK * level * 2
                    MP -= 5
                    print(name + " used " + ability)
                    print(name + " hit twice, dealing " + str(ATK * level * 2) + " damage to the " + enemy + ".")
                else:
                    print("You don't have enough mana! The " + enemy + " while you were helpless!")
            elif job == "Rogue":
                if r == 1 and MP >= 5:
                    hp -= ATK * level * 3
                    MP -= 5
                    print(name + " used " + ability)
                    print(name + " hit the " + enemy + " from the shadows, dealing " + str(ATK * level * 3) +
                          " damage to it.")
                elif r == 1 and MP < 5:
                    print("You don't have enough mana! The " + enemy + " attacked you while you're helpless!")
                elif r > 1:
                    print("You can only use this Ability at the beginning of combat!")
            elif job == "Mage":
                if MP >= 9:
                    hp -= MPMAX * level * 0.5
                    MP -= 9
                    print(name + " used " + ability)
                    print(name + " threw a massive fireball, dealing " + str(MPMAX * level * 0.5) +
                          " damage to the " + enemy + ".")
                else:
                    print("You don't have enough mana! The " + enemy + " attacked you while you were helpless!")
            elif job == "Warlock":
                clear()
                if MP >= 7:
                    hp -= HPMAX * level * 0.1
                    HP += HPMAX * level * 0.1
                    MP -= 7
                    if HP > HPMAX * level:
                        HP = HPMAX * level
                    print(name + " used " + ability)
                    print(name + " leeched " + str(HPMAX * level * 0.1) + " health from the " + enemy + "!")
                else:
                    print("You don't have enough mana! The " + enemy + " attacked you while you were helpless!")
            elif job == "Shaman":
                if MP >= level * totem:
                    MP -= level * totem
                    totem += 1 * level
                    print(name + " used " + ability)
                    print(name + " summoned another totem to attack the " + enemy + "!")
                    print(" There are now " + str(totem) + " on the field!")
                else:
                    print("You don't have enough mana! The " + enemy + " attacked you while you were helpless!")
        elif choice_battle == "3":
            clear()
            if pot > 0:
                pot -= 1
                heal(20)
                print(enemy + " dealt " + str(at) + " damage to " + name + ".")
            else:
                print("No potions!")
        elif choice_battle == "4":
            clear()
            if elix > 0:
                elix -= 1
                mana(20)
                print(enemy + " dealt " + str(at) + " damage to " + name + ".")
            else:
                print("No elixirs!")
        if totem > 0:
            hp -= totem * TATK * level
            if totem == 1:
                print("The totem attacked the " + enemy + " for " + str(totem * TATK * level) + "!")
            if totem > 1:
                print("The totems attacked the " + enemy + " for " + str(totem * TATK * level) + "!")
        if int(HP) > 0:
            HP -= at
            print(enemy + " dealt " + str(at) + " damage to " + name + ".")
        if int(HP) <= 0:
            print(enemy + " defeated " + name + "...")
            draw()
            print("GAME OVER")
            fight = False
            mainmenu()

        if int(hp) <= 0:
            print(name + " defeated the " + enemy + "!")
            draw()
            fight = False
            gold += go
            print("You've found " + str(go) + " gold!")

            if random.randint(0, 100) < 30:
                pot += 1
                print("You've found a potion!")
            if random.randint(0, 100) > 70:
                elix += 1
                print("You've found an elixir!")
            if quest_enemy < 2:
                quest_enemy += 1
                if quest_enemy == 2:
                    level += 1
                    gold += 100
                    print("You've completed your quest and increased your level to " + str(level) + "!")
                    print("You received 100 gold for your troubles!")
                    print("Go back to the mayor to continue!")
            elif quest_enemy == 2 and quest_goblins < 4:
                quest_goblins += 1
                if quest_goblins == 4:
                    print("You've completed your quest and increased your level to " + str(level) + "!")
                    print("You received 100 gold for your troubles!")
                    print("Go back to the mayor to continue!")
                    level += 1
                    gold += 100
            elif quest_goblins == 4 and quest_orcs < 2:
                quest_orcs += 1
                if quest_orcs == 2:
                    print("You've completed your quest and increased your level to " + str(level) + "!")
                    print("You received 100 gold for your troubles!")
                    print("Go back to the mayor to continue!")
                    level += 1
                    gold += 100
            elif quest_orcs == 2 and quest_slimes < 4:
                quest_slimes += 1
                if quest_slimes == 4:
                    print("You've completed your quest and increased your level to " + str(level) + "!")
                    print("You received 100 gold for your troubles!")
                    print("Go back to the mayor to continue!")
                    level += 1
                    gold += 100
            elif quest_slimes == 4 and quest_harpies < 2:
                quest_harpies += 1
                if quest_harpies == 4:
                    print("You've completed your quest and increased your level to " + str(level) + "!")
                    print("You received 100 gold for your troubles!")
                    print("Go back to the mayor to continue!")
                    level += 1
                    gold += 100
            elif quest_harpies == 4 and quest_minotaurs == 1:
                if random.randint(0, 100) < 30:
                    print("Your key merges with the magic in your backpack.")
                    print("It is now enchanted! Return to the mayor at once!")
                    print("You've completed your quest and increased your level to " + str(level) + "!")
                    print("You received 100 gold for your troubles!")
                    level += 1
                    gold += 100
                    quest_minotaurs += 1
            elif keymaterial:
                if random.randint(0, 100) < 30:
                    print("You've found a bronze bar!")
                    print("This is the perfect material for forging your key!")
                    print("Return to the mayor at once!")
                    print("You've completed your quest and increased your level to " + str(level) + "!")
                    print("You received 100 gold for your troubles!")
                    level += 1
                    gold += 100
                    keymaterial = False
            elif boss:
                draw()
                print("Congratulations, you've finished the game! Achievements are now unlocked!")
                print("You've also gained a talent:")
                boss = False
    input("Press Enter to continue")
    draw()


def shop(buy):
    global map, biom, y_len, x_len, e_list, gold, pot, elix, job, TATK, level, ATK, name, HPMAX, MPMAX, keymaterial
    while buy:
        clear()
        draw()
        print("Welcome to the shop!")
        draw()
        print("GOLD: " + str(gold))
        print("POTIONS: " + str(pot))
        print("ELIXIRS: " + str(elix))
        if job == "Shaman":
            print("TOTEM ATK:" + str(TATK * level))
        elif job == "Warrior" or job == "Warlock" or job == "Mage" or job == "Rogue":
            print("ATK: " + str(ATK * level))
        print("MAXHP:" + str(HPMAX * level))
        print("MAXMP:" + str(MPMAX * level))
        draw()
        print("1 - BUY POTION (" + str(20 * level) + "HP) - 5 GOLD")
        print("2 - BUY ELIXIR (" + str(20 * level) + "MP) - 5 GOLD")
        if job == "Shaman":
            print("3 - UPGRADE WEAPON (+" + str(2 * level) + "TOTEM ATK) - 10 GOLD")
        else:
            print("3 - UPGRADE WEAPON (+" + str(2 * level) + "ATK) - 10 GOLD")
        print("4 - UPGRADE ARMOR (+" + str(2 * level) + "HP)- 10 GOLD")
        print("5 - UPGRADE TRINKETS (+" + str(2 * level) + "MP)- 10 GOLD")
        if keymaterial:
            print("6 - BUY MATERIAL (INSTANT LEVEL-UP) - 100 GOLD")
            print("7 - LEAVE")
        else:
            print("6 - LEAVE")
        draw()

        choice_shop = input("> ")
        draw()

        if choice_shop == "1":
            if gold >= 5:
                pot += 1
                gold -= 5
                print("You've bought a potion!")
            else:
                print("Not enough gold!")
        elif choice_shop == "2":
            if gold >= 5:
                elix += 1
                gold -= 5
                print("You've bought an elixir!")
            else:
                print("Not enough gold!")
        elif choice_shop == "3":
            if gold >= 10:
                if job == Shaman:
                    TATK += 2 * level
                else:
                    ATK += 2 * level
                gold -= 10
                print("You've upgraded your weapon!")
            else:
                print("Not enough gold!")
        elif choice_shop == "4":
            if gold >= 10:
                HPMAX += 2 * level
                gold -= 10
                print("You've upgraded your armor!")
            else:
                print("Not enough gold!")
        elif choice_shop == "5":
            if gold >= 10:
                MPMAX += 2 * level
                gold -= 10
                print("You've upgraded your trinkets!")
            else:
                print("Not enough gold!")
        elif choice_shop == "6":
            if keymaterial:
                if gold >= 100:
                    print("You completed your quest and gained a level!")
                    print("It's time to return to the mayor.")
                    level += 1
                else:
                    print("Not enough gold!")
            else:
                buy = False
        elif choice_shop == "7":
            if keymaterial:
                buy = False
    clear()


def mayor():
    global map, biom, y_len, x_len, e_list, name, quest_minotaurs, quest_goblins, quest_slimes, quest_harpies, \
        quest_orcs, quest_enemy, keymaterial, keymold, keyenchant, pot, elix
    clear()
    draw()
    print("Mayor: Hello there, " + name + "!")
    while quest_enemy == 0:
        print("Mayor: I hear you're looking for adventure!")
        print("Mayor: How about you go out and kill an enemy for us? Any will do!")
        print("You now have a quest!")
        quest_enemy += 1
        break
    while quest_enemy == 2 and quest_goblins < 4:
        print("Mayor: You've done well! Here's some gold for your troubles. Now, let's get down to business.")
        print("Mayor: You see, we are besieged by so many creatures. The biggest nuisance being the Goblins.")
        print("Mayor: If you can clear out 4 Goblins, we would be grateful.")
        print("You now have a new quest!")
        break
    while quest_goblins == 4 and quest_orcs < 2:
        print("Mayor: Amazing! You surprised me!")
        print("Mayor: Now that the Goblins are gone, the next issue is Orcs.")
        print("Mayor: Please clear out 2 Orcs for us!")
        break
    while quest_orcs == 2 and quest_slimes < 4:
        print("Mayor: You're doing so well! Keep it up!")
        print("Mayor: I was going to send you after Harpies next, but Slimes have started getting out of hand!")
        print("Mayor: Please clear out 4 Slimes for us!")
        break
    while quest_slimes == 4 and quest_harpies < 2:
        print("Mayor: Thank goodness you've defeated those dastardly Slimes!")
        print("Mayor: Now, let's move on to Harpies. They are stealing our grain and must be stopped!")
        print("Mayor: Please defeat 2 Harpies for us!")
        break
    while quest_harpies == 2 and keymold == 0:
        print("Mayor: Now you're experienced with the kind of monsters we are facing.")
        print("Mayor: They're all led by the evil dragon that lurks inside his cave.")
        print("Mayor: Unfortunately, this cave is protected by a magical door.")
        print("Mayor: An enchanted key is necessary to open it.")
        print("Mayor: First, we must mold the key.")
        print("Mayor: Go east until you reach the cave, and use this putty to make a key.")
        keymold += 1
        break
    while keymold == 2:
        print("Mayor: Perfect, you've got the key mold!")
        print("Mayor: Now to get the key material.")
        print("You can buy one from the shop to the southeast, or you can possibly find one on an enemy.")
        keymaterial += 1
        break
    while keymaterial == 2:
        print("Mayor: Perfect! You have the material!")
        print("Mayor: Give my blacksmiths a little while to craft the key.")
        print("Mayor: In the meantime, I want you to buy the materials to enchant the key.")
        print("Mayor: Bring me 10 elixirs and 10 potions. That should provide enough magical energy.")
        keyenchant += 1
        break
    while keyenchant == 1 and pot >= 10 and elix >= 10:
        print("Mayor: Oh good! you've got the necessary items! Hand them over, will you?")
        pot_choice = input("Would you like to hand over 10 elixirs and 10 potions? (y/n)")
        if pot_choice.lower() == "y":
            pot -= 10
            elix -= 10
            level += 1
            keyenchant += 1
            break
        elif pot_choice.lower() == "n":
            print("Mayor: Oh, OK. Please hand them in when you're ready.")
            break
    while keyenchant == 1 and pot < 10:
        print("Mayor: You need more potions!")
        break
    while keyenchant == 1 and elix < 10:
        print("Mayor: You need more elixirs!")
        break
    while quest_minotaurs == 0 and keyenchant == 2:
        print("Mayor: We're so close to ridding ourselves of that terrible dragon!")
        print("Mayor: The final step is to enchant the key")
        print("Mayor: The magic is all here, however we need to unlock it!")
        print("Mayor: Luckily, the dragon made a mistake as we got closer.")
        print("Mayor: He sent Minotaurs after us!")
        print("Mayor: Minotaurs are his top lieutenants, but killing them is the way to enchanting the key.")
        print("Mayor: Kill Minotaurs until you've unlocked the magic!")
        quest_minotaurs += 1
        break
    while quest_minotaurs == 2:
        print("Mayor: It is time to take on the dragon!")
        print("Mayor: Take the finished key with you, but be careful with the beast!")
        print("You now can take on the evil Dragon! Look on your map for the cave!")
        break

    draw()
    print("1 - LEAVE")
    draw()

    choice_leave = input("> ")

    if choice_leave == "1":
        play(standing=True)


def cave():
    global map, biom, y_len, x_len, e_list, keymold, quest_minotaurs
    draw()
    print("Here lies the door to the lair of the dragon. What will you do?")
    if keymold == 1:
        print("1 - MAKE KEY MOLD")
    if quest_minotaurs == 2:
        print("1 - USE FINISHED KEY")
    print("2 - TURN BACK")
    draw()

    choice_cave = input("> ")
    clear()
    if choice_cave == "1":
        if keymold == 1:
            print("You walk up to the door and make the mold. Time to return to the Mayor.")
            print("Congratulations! You finished the quest and increased your level!")
            level += 1
            keymold += 1
        if quest_minotaurs == 2:
            clear()
            battle()
    elif choice_cave == "2":
        clear()


def h2p():
    clear()
    print("How to Play:")
    print("This game is about doing quests to level to 10 so you can defeat the Dragon!")
    print("Each quest completed will increase your level by 1")
    print("Use the number keys to change between menus and move around the map.")
    print("You can press 0 at any time to save and return to the main menu.")
    cont1 = input("Continue? (y/n)")
    if cont1.lower() == "y":
        print("You can choose from 4 jobs. Each job starts with a unique ability.")
        print("Warrior - Berserk: Attacks twice.")
        print("Rogue - Sneak Attack: Deals massive damage based on ATK in the first round of each fight.")
        print("Mage - Fireball: Deals damage based on MP")
        print("Warlock - Life Leech: Restores health based on damage output")
        cont2 = input("Continue? (y/n)")
        if cont2.lower() == "y":
            print("You will start in a Town. Going east will take you to the mayor's house.")
            print("This is where you can pick up quests.")
            print("You can also visit the shop in the southern part of town to upgrade your gear.")
            print("You need to kill enemies in the wilderness to get the gold for upgrades.")
            print("Going south of the shop or east of the Mayor's house will take you to the bridge.")
            print("This bridge will lead you to the wilderness where you can encounter enemies.")
            cont3 = input("Continue? (y/n)")
            if cont3.lower() == "y":
                print("Once you've finished the main story, you will unlock achievements.")
                print("You will no longer gain levels, however you WILL gain something new: talents!")
                print("The talent you get is based on the achievement type.")
                print("For example: 'slayer' achievements give bonus ATK and 'shop' achievements give bonus MP")
                print("Collect all the achievements and send me a screenshot to be added to the Hall of Fame!")
                print("The Hall of Fame can be found on the GitHub page and in the ReadMe. Now go enjoy yourself!")
                cont4 = input("Would you like a few tips on completing the game? (y/n")

                if cont4 == "y":
                    print("Warriors will start slow, but can be helped if you upgrade their weapons.")
                    print("Warlocks' Life Leech damage/healing are based on MAXHP, so upgrade your trinkets!")
                    print("Mages will literally 1-shot everything, except the Dragon...")
                    print("Rogues will also 1-shot everything at first, but will get harder as you go.")
                    back_to_menu = input("Press 1 when you're ready to go back to the main menu.")
                    if back_to_menu == "1":
                        mainmenu()
                        clear()
                    else:
                        print("You're not very good at following directions,are you?")
                        mainmenu()
                        clear()
                elif cont4 == "n":
                    mainmenu()
                    clear()
            elif cont3.lower() == "n":
                mainmenu()
        elif cont2.lower() == "n":
            mainmenu()
    elif cont1.lower() == "n":
        mainmenu()


def play(standing):
    global biom, map, e_list, x, y, name, job, level, HP, MP, HPMAX, MPMAX, TATK, ATK, pot, elix, gold
    while run:
        if not standing:
            if biom[map[y][x]]["e"]:
                if random.randint(0, 10) < 3:
                    clear()
                    battle()
                else:
                    standing = True
            else:
                standing = True
        while standing:
            clear()
            draw()
            print("LOCATION: " + biom[map[y][x]]["t"])
            draw()
            print("NAME: " + str(name))
            print("JOB: " + str(job))
            print("LEVEL: " + str(level))
            print("HP: " + str(HP) + "/" + str(HPMAX * level))
            print("MP: " + str(MP) + "/" + str(MPMAX * level))
            if job == "Shaman":
                print("TOTEM ATK:" + str(TATK * level))
            else:
                print("ATK: " + str(ATK * level))
            print("POTIONS: " + str(pot))
            print("ELIXIRS: " + str(elix))
            print("GOLD: " + str(gold))
            print("COORD: ", x, y)
            draw()
            print("0 - SAVE AND QUIT")
            print("1 - MAP")
            if y > 0:
                print("2 - NORTH")
            if x < x_len:
                print("3 - EAST")
            if y < y_len:
                print("4 - SOUTH")
            if x > 0:
                print("5 - WEST")
            if pot > 0:
                print("6 - USE POTION (" + str(20 * level) + "HP)")
            if elix > 0:
                print("7 - USE ELIXIR (" + str(20 * level) + "MP)")
            if map[y][x] == "shop" or map[y][x] == "mayor" or map[y][x] == "cave":
                print("8 - ENTER")
            draw()

            dest = input("> ")
            if dest == "0":
                exit()
            elif dest == "1":
                clear()
                map_menu()
            elif dest == "2":
                if y > 0:
                    y -= 1
                    standing = False
            elif dest == "3":
                if x < x_len:
                    x += 1
                    clear()
                    standing = False
            elif dest == "4":
                if y < y_len:
                    y += 1
                    clear()
                    standing = False
            elif dest == "5":
                if x > 0:
                    x -= 1
                    clear()
                    standing = False
            elif dest == "6":
                if pot > 0:
                    pot -= 1
                    heal(20)
                else:
                    print("No potions!")
                clear()
                standing = True
            elif dest == "7":
                if elix > 0:
                    elix -= 1
                    mana(20)
                else:
                    print("No elixirs!")
                clear()
                standing = True
            elif dest == "8":
                if map[y][x] == "shop":
                    clear()
                    shop(buy=True)
                if map[y][x] == "mayor":
                    clear()
                    mayor()
                if map[y][x] == "cave":
                    clear()
                    cave()


def main_menu():
    global name, job, ability, HPMAX, MPMAX, ATK, TATK, HP, MP
    print("This is V2.0 of my text-based RPG!")
    print("I did my best to implement as much as possible in the past week.")
    print("Unfortunately, I could not make saving with the time given.")
    print("The next patch will release save files and much more, but for now...")
    print("Please enjoy my (almost) finished game!")
    print("Now, what is your name?")
    name = input(">")
    print("Perfect! Welcome, " + name + "!")
    print("Now to pick a job:")
    print("1. Warrior: High hp, low mp and atk")
    print("2. Rogue: High atk, low mp and hp")
    print("3. Mage: High mp, low atk and hp")
    print("4. Warlock: Average stats")
    print("5. Shaman: Average hp, High mp, relies on totems to attack")
    job_choice = input("What will your job be? ")
    if job_choice == "1":
        job = "Warrior"
        ability = "Berserk"
        HPMAX = 45
        MPMAX = 25
        ATK += 3
        TATK += 0
        HP = HPMAX
        MP = MPMAX
    elif job_choice == '2':
        job = "Rogue"
        ability = "Sneak Attack"
        HPMAX = 25
        MPMAX = 25
        ATK += 5
        TATK += 0
        HP = HPMAX
        MP = MPMAX
    elif job_choice == '3':
        job = "Mage"
        ability = "Fireball"
        HPMAX = 25
        MPMAX = 45
        ATK += 3
        TATK += 0
        HP = HPMAX
        MP = MPMAX
    elif job_choice == "4":
        job = "Warlock"
        ability = "Life Leech"
        HPMAX = 35
        MPMAX = 35
        ATK += 4
        TATK += 0
        HP = HPMAX
        MP = MPMAX
    elif job_choice == "5":
        job = "Shaman"
        ability = "Summon Totem"
        HPMAX = 35
        MPMAX = 45
        ATK += 0
        TATK += 1
        HP = HPMAX
        MP = MPMAX
    print("Perfect! Your job is " + str(job) + "! Your ability is " + ability + "!")
    print("Your HP is " + str(HP) + " and your MP is " + str(MP) + "!")
    print("Now, let's start your adventure!")
    play(standing=True)


while run:
    main_menu()
