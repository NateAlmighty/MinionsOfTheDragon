# Minions of the Dragon
A Text RPG Game created for my own fun times!
Please leave me feedback when you have the chance!

# Fellow Coders:
You can now add to the current code file in Github!
I have made the python release open for all to view and tweak where you think it'd be best
<3 Much love!

# Update Schedule
Due to the massive support for my game, I've been working relentlessly on updates. Sometimes though, you need a break. So, here's what to expect starting now:

* Weekly patches to fix any bugs that are found
* Monthly updates to add new in-game content


# How To Download And Play:
1. Choose which version you want to download (I highly suggest the latest release)
2. Click the .zip file for selected version
3. Click the "download" button on the bottom-right side of the screen
4. Choose your destination
5. Extract the zip file and run the .exe
6. Enjoy!

# V1.0:

* Includes a basic combat system with potions, and attack
* Includes a basic exploration system that allows you to find enemies, go back to the shop to restock potions and elixirs or upgrade your weapon, and talk to the Mayor.
* Includes a weapon leveling system that unlocks the end boss, the Dragon, at level 10.
* Includes a single-file save/load system.

# Add in Future:

1. Classes
2. Abilities
3. More Shop Options
4. Mayor Quests
5. More Monster Types
7. Endgame
