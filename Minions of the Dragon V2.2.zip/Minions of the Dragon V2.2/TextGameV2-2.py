import os
import random
import time
import pickle

actions = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'}

# x = 0  x = 1    x = 2    x = 3      x = 4       x = 5     x = 6
map = [["town", "mayor", "bridge", "plains", "forest", "mountain", "cave"],  # y = 0
       ["shop", "forest", "forest", "forest", "forest", "hills", "mountain"],  # y = 1
       ["bridge", "fields", "plains", "hills", "forest", "hills", "hills"],  # y = 2
       ["plains", "fields", "plains", "hills", "forest", "hills", "mountain"],  # y = 3
       ["plains", "fields", "fields", "plains", "hills", "mountain", "mountain"]]  # y = 4)

y_len = len(map) - 1
x_len = len(map[0]) - 1

biom = {
    "plains": {
        "t": "PLAINS",
        "e": True },
    "forest": {
        "t": "WOODS",
        "e": True },
    "fields": {
        "t": "FIELDS",
        "e": False },
    "bridge": {
        "t": "BRIDGE",
        "e": True },
    "town": {
        "t": "TOWN CENTRE",
        "e": False },
    "shop": {
        "t": "SHOP",
        "e": False },
    "mayor": {
        "t": "MAYOR",
        "e": False },
    "cave": {
        "t": "CAVE",
        "e": False },
    "mountain": {
        "t": "MOUNTAIN",
        "e": True },
    "hills": {
        "t": "HILLS",
        "e": True,
    }
}

x = 0
y = 0
run = True
standing = False
fight = False
name = "name"
level = 1
job = ["Warrior", "Rogue", "Mage", "Warlock", "Shaman"]
ability = ["Berserk", "Sneak Attack", "Fireball", "Life Leech", "Summon Totem"]
HP = 0
MP = 0
HPMAX = 0
MPMAX = 0
ATK = 0
TATK = 0
pot = 1
elix = 1
quest_minotaurs = 0
quest_harpies = 0
quest_enemy = 0
quest_goblins = 0
quest_orcs = 0
quest_slimes = 0
keymaterial = 0
keymold = 0
keyenchant = 0
boss = False
gold = 0
completed_quest = False
endgame = False
hpmax = 0
hp = 0
at = 0
enemy = "Goblin"

achievements = {
    'Exploration': [
        {'Name': 'Plains Explorer', 'Required': 'Areas Explored Plains', 'Goal': 25, 'MAXHP1 Increase': 10},
        {'Name': 'Woods Explorer', 'Required': 'Areas Explored Woods', 'Goal': 25, 'MAXHP2 Increase': 10},
        {'Name': 'Fields Explorer', 'Required': 'Areas Explored Fields', 'Goal': 25, 'MAXHP3 Increase': 10},
        {'Name': 'Mountain Explorer', 'Required': 'Areas Explored Mountain', 'Goal': 25, 'MAXHP4 Increase': 10},
        {'Name': 'Hills Explorer', 'Required': 'Areas Explored Hills', 'Goal': 25, 'MAXHP5 Increase': 10},
        {'Name': 'Bridge Explorer', 'Required': 'Areas Explored Bridge', 'Goal': 25, 'MAXHP6 Increase': 10},
    ],
    'Slayer': [
        {'Name': 'Goblin Slayer', 'Required': 'Enemies Killed Goblin', 'Goal': 25, 'ATK1 Increase': 10},
        {'Name': 'Orc Slayer', 'Required': 'Enemies Killed Orc', 'Goal': 25, 'ATK2 Increase': 10},
        {'Name': 'Slime Slayer', 'Required': 'Enemies Killed Slime', 'Goal': 25, 'ATK3 Increase': 10},
        {'Name': 'Harpy Slayer', 'Required': 'Enemies Killed Harpy', 'Goal': 25, 'ATK4 Increase': 10},
        {'Name': 'Minotaur Slayer', 'Required': 'Enemies Killed Minotaur', 'Goal': 25, 'ATK5 Increase': 10},
        {'Name': "Dragon's Mate Slayer", 'Required': "Enemies Killed Dragon's Mate", 'Goal': 25, 'ATK6 Increase': 10},
    ],
    'Shopping': [
        {'Name': 'Elixir Enthusiast', 'Required': 'Elixirs Bought', 'Goal': 25, 'MAXMP1 Increase': 10},
        {'Name': 'Potion Pro', 'Required': 'Potions Bought', 'Goal': 25, 'MAXMP2 Increase': 10},
        {'Name': 'Weapon Upgrade Specialist', 'Required': 'Weapon Upgrades Bought', 'Goal': 25, 'MAXMP3 Increase': 10},
        {'Name': 'Armor Upgrade Ace', 'Required': 'Armor Upgrades Bought', 'Goal': 25, 'MAXMP4 Increase': 10},
        {'Name': 'Trinket Upgrade Expert', 'Required': 'Trinket Upgrades Bought', 'Goal': 25, 'MAXMP5 Increase': 10},
    ],
    'Meta': [
        {'Name': 'Master Explorer', 'Required': 'All Exploration achievements completed', 'Goal': 6,'All Stats Increase'
        : 100},
        {'Name': 'Master Slayer', 'Required': 'All Slayer achievements completed', 'Goal': 6, 'All Stats Increase':
            100},
        {'Name': 'Master Shoper', 'Required': 'All Shopping achievements completed', 'Goal': 5, 'All Stats Increase':
            100}
    ]
}

progress = {}

tracked = []


def name_color():
    global name
    return f"\033[1;35m{name}\033[0m"


def job_color():
    global job
    return f"\033[1;35m{job}\033[0m"


def ability_color():
    global ability
    return f"\033[1;35m{ability}\033[0m"


def gold_color():
    global gold
    return f"\033[1;33m{gold}\033[0m"


def level_color():
    global level
    return f"\033[1;33m{level}\033[0m"


def HP_color():
    global HP
    return f"\033[1;32m{HP}\033[0m"


def HPMAX_color():
    global HPMAX, level
    return f"\033[1;32m{HPMAX * level}\033[0m"


def MP_color():
    global MP
    return f"\033[1;34m{MP}\033[0m"


def MPMAX_color():
    global MPMAX, level
    return f"\033[1;34m{MPMAX * level}\033[0m"


def TATK_color():
    global TATK, level
    return f"\033[1;31m{TATK * level}\033[0m"


def ATK_color():
    global ATK, level
    return f"\033[1;31m{ATK * level}\033[0m"


def x_color():
    global x
    return f"\033[1;33m{x}\033[0m"


def y_color():
    global y
    return f"\033[1;33m{y}\033[0m"


def typewriter(text):
    sentences = text.split(". ") or text.split("! ")  # split text into sentences based on ". " or "! "
    for sentence in sentences:
        for char in sentence:
            print(char, end="", flush=True)
            time.sleep(0.01)
        print("")  # print a newline character


class SaveGlobals:
    def __init__(self):
        self.filename_template = 'globals_{}.pkl'
        self.default_vars = {
            "x": 0,
            "y": 0,
            "run": True,
            "standing": True,
            "fight": False,
            "name": "NAAAAH",
            "level": 1,
            "job": "job",
            "ability": "ability",
            "HP": 0,
            "MP": 0,
            "HPMAX": 0,
            "MPMAX": 0,
            "ATK": 0,
            "TATK": 0,
            "pot": 1,
            "elix": 1,
            "quest_minotaurs": 0,
            "quest_harpies": 0,
            "quest_enemy": 0,
            "quest_goblins": 0,
            "quest_orcs": 0,
            "quest_slimes": 0,
            "keymaterial": False,
            "keymold": 0,
            "keyenchant": 0,
            "boss": False,
            "gold": 0,
            "completed_quest": False,
            "endgame": False,
            "hpmax": 0,
            "hp": 0,
            "at": 0,
            "enemy": "Goblin"
        }

    def save(self, slot=0):
        while standing:
            filename = self.filename_template.format(slot)
            with open(filename, 'wb') as f:
                pickle.dump(globals(), f)
            print(f"Game variables saved to slot {slot}.")

    def load(self, slot):
        filename = self.filename_template.format(slot)
        try:
            with open(filename, 'rb') as f:
                global_vars = pickle.load(f)
        except FileNotFoundError:
            with open(filename, 'wb') as f:
                pickle.dump({}, f)
                global_vars = {}

        for var_name, var_value in self.default_vars.items():
            if var_name not in global_vars:
                global_vars[var_name] = var_value

        globals().update(global_vars)
        typewriter(f"Game variables loaded from slot {slot}.")


def load_game():
    typewriter("Enter the save slot to load (0-9):")
    slot = int(input("> "))
    save_globals = SaveGlobals()
    save_globals.load(slot)


def save_game():
    typewriter("Enter the save slot to save to (0-9):")
    slot = int(input("> "))
    save_globals = SaveGlobals()
    save_globals.save(slot)


def map_menu():
    typewriter('  #x = 0       x = 1       x = 2       x = 3       x = 4       x = 5          x = 6')
    typewriter('[["town"      "mayor"     "bridge"    "plains"    "forest"   "mountain"       "cave"]      y = 0')
    typewriter('["shop",     "forest",    "forest",   "forest",   "forest",   "hills",       "mountain"],  y = 1')
    typewriter('["bridge",   "fields",    "plains",   "hills",    "forest",   "hills",        "hills"  ],  y = 2')
    typewriter('["plains"   ,"fields",    "plains",    "hills",   "forest"  , "hills",       "mountain"],  y = 3')
    typewriter('["plains",   "fields",    "fields",    "plains",   "hills",  "mountain",     "mountain"]   y = 4')


def track_achievement(achievement_name):
    if endgame:
        for category in achievements:
            for achievement in achievements[category]:
                if achievement['Name'] == achievement_name:
                    if len(tracked) < 3:
                        if achievement_name in progress:
                            tracked.append(achievement_name)
                            typewriter(f"{achievement_name} has been added to the tracked achievements.")
                        else:
                            typewriter(f"{achievement_name} can not be tracked.")
                    else:
                        typewriter("You can only track up to 3 achievements at a time.")


def print_achievements():
    if endgame:
        categories = ["Exploration", "Slayer", "Shop", "Meta"]
        typewriter("Categories:")
        for i, category in enumerate(categories):
            typewriter(f"{i + 1} - {category}")
        typewriter("Which category would you like to look at?")
        category_index = int(input("> ")) - 1
        if category_index == -1:
            play()
        elif 0 <= category_index < len(categories):
            category = categories[category_index]
            if category in achievements:
                typewriter(category)
                for achievement in achievements[category]:
                    typewriter(f"\t{achievement['Name']} - {achievement['Required']}: {achievement['Goal']}:"
                               f" {achievement['Progress']}")
                    typewriter("Do you want to track an achievement? (y/n)")
                    track = input("> ").lower()
                    if track == "y":
                        typewriter("Which achievement do you want to track?")
                        achievement_name = input("> ")
                        track_achievement(achievement_name)
                    elif track == "n":
                        print_achievements()
                    else:
                        play()
            else:
                typewriter("This category has no achievements.")
                print_achievements()
        else:
            typewriter("Invalid category selected.")
            print_achievements()


def clear():
    time.sleep(2)
    os.system("cls")


def draw():
    typewriter("xX--------------------xX")


def heal_mana(value, resource, resource_name):
    if resource > 1:
        resource -= 1
        value(20)
    else:
        typewriter(f"No {resource_name}s!")
    clear()


def battle():
    global level, name, HP, HPMAX, MP, MPMAX, job, ATK, ability, pot, elix, boss, gold, \
        completed_quest, endgame, fight, achievements, quest_minotaurs, quest_goblins, \
        quest_slimes, quest_orcs, quest_harpies, quest_enemy, hpmax, hp, at, enemy
    totem = 0
    enemy_list = ["Goblin", "Orc", "Slime", "Harpy", "Minotaur", "Dragon's Mate"]
    # Determine the type and stats of the enemy
    if not boss:
        if quest_enemy < 2:
            enemy = "Goblin"
        elif quest_enemy == 2 and quest_goblins < 4:
            enemy = "Goblin"
        elif quest_goblins == 4 and quest_orcs < 2:
            enemy = "Orc"
        elif quest_orcs == 2 and quest_slimes < 4:
            enemy = "Slime"
        elif quest_slimes == 4 and quest_harpies < 2:
            enemy = "Harpy"
        elif quest_harpies == 2 and not endgame:
            enemy = "Minotaur"
        elif endgame:
            enemy = random.choice(enemy_list)
    else:
        enemy = "Dragon"

    hpmax = (15 * level if enemy == "Goblin" else 35 * level if enemy == "Orc"
    else 30 * level if enemy == "Slime" else 45 * level if enemy == "Harpy"
    else 50 * level if enemy == "Minotaur" else 250 * level if enemy == "Dragon's Mate"
    else 250 * level if enemy == "Dragon" else 0)

    at = (3 * level if enemy == "Goblin" else 4 * level if enemy == "Orc"
    else 5 * level if enemy == "Slime" else 6 * level if enemy == "Harpy"
    else 7 * level if enemy == "Minotaur" else 10 * level if enemy == "Dragon's Mate"
    else 10 * level if enemy == "Dragon" else 0)

    go = (8 * level if enemy == "Goblin" else 10 * level if enemy == "Orc"
    else 13 * level if enemy == "Slime" else 15 * level if enemy == "Harpy"
    else 20 * level if enemy == "Minotaur" else 100 * level if enemy == "Dragon"
    else 100 * level if enemy == "Dragon's Mate" else 0)

    hp = hpmax

    while fight:
        # Draw the game screen
        clear()
        draw()
        typewriter("Defeat the " + enemy + "!")
        draw()
        typewriter(f"{enemy}'s HP: {hp} / {hpmax}")
        typewriter(enemy + "'s LEVEL: " + level_color())
        typewriter(name_color() + "'s HP: " + HP_color() + "/" + HPMAX_color())
        typewriter(name_color() + "'s MP: " + MP_color() + "/" + MPMAX_color())
        typewriter("POTIONS: " + str(pot))
        typewriter("ELIXIRS: " + str(elix))
        draw()

        # Display options
        if job == "Shaman":
            typewriter("1 - Skip Turn")
        elif job in ["Warrior", "Warlock", "Mage", "Rogue"]:
            typewriter("1 - ATTACK")
        typewriter("2 - ABILITY")
        if pot > 0:
            typewriter("3 - USE POTION " + str(20 * level) + "HP")
        if elix > 0:
            typewriter("4 - USE ELIXIR " + str(20 * level) + "MP")
        typewriter("5 - ATTEMPT FLEE")
        draw()
        choice_battle = input()
        clear()
        if choice_battle == "1":
            if job == "Shaman":
                typewriter("Turn skipped!")
            elif job in ["Warrior", "Warlock", "Mage", "Rogue"]:
                hp -= ATK * level
                typewriter(name_color() + " dealt " + ATK_color() + " damage to the {enemy}.")
        elif choice_battle == "2":
            if job == "Warrior":
                if MP >= 5:
                    hp -= ATK * level * 2
                    MP -= 5
                    typewriter(name_color() + ' used ' + ability_color() + '!')
                    typewriter(name_color() + " hit twice, dealing " + ATK_color() * 2 + " damage to the {enemy}.")
                else:
                    typewriter(f"You don't have enough mana! The {enemy} attacked you while you were helpless!")
            elif job == "Rogue":
                if MP >= 5:
                    hp -= ATK * level * 3
                    MP -= 5
                    typewriter(name_color() + " used " + ability_color())
                    typewriter(name_color() + " hit the {enemy} from the shadows, dealing " + ATK_color() * 3 +
                               " damage to it.")
                else:
                    typewriter(f"You don't have enough mana! The {enemy} attacked you while you were helpless!")
            elif job == "Mage":
                if MP >= 9:
                    hp -= MPMAX * level * 0.5
                    MP -= 9
                    typewriter(name_color() + ' used ' + ability_color() + '!')
                    typewriter(name_color() + " threw a massive fireball, dealing "
                    + str(MPMAX * level * 0.5) + " damage to the " + enemy + ".")
                else:
                    typewriter(f"You don't have enough mana! The {enemy} attacked you while you were helpless!")
            elif job == "Warlock":
                if MP >= 7:
                    hp -= HPMAX * level * 0.1
                    HP += HPMAX * level * 0.1
                    MP -= 7
                    HP = min(HP, HPMAX * level)
                    typewriter(name_color() + ' used ' + ability_color() + '!')
                    typewriter(name_color() + " leeched {HPMAX * level * 0.1} health from the {enemy}!")
                else:
                    typewriter(f"You don't have enough mana! The {enemy} attacked you while you were helpless!")
            elif job == "Shaman":
                if MP >= level * totem:
                    MP -= level * totem
                    totem += 1 * level
                    typewriter(name_color() + ' used ' + ability_color() + '!')
                    typewriter(name_color() + " summoned another totem to attack the " + enemy + "!")
                    typewriter(name_color() + "'s totems attacked for " + totem * TATK_color() + "!")
        elif choice_battle == "3":
            heal_mana(20, pot, "potion")
        elif choice_battle == "4":
            heal_mana(20, elix, "elixir")
        elif choice_battle == "5":
            typewriter(name_color() + "Attempted to flee...")
            if random.randint(0, 10) > 3:
                typewriter("...and succeeded!")
                fight = False
            else:
                typewriter("...and failed! The " + enemy + " hit them while their back was turned!")
        if int(HP) <= 0:
            typewriter(enemy + " defeated " + name_color())
            typewriter("GAME OVER")
            fight = False
            main_menu()
        else:
            HP -= at
            typewriter(enemy + " dealt " + str(at) + " damage to " + name_color() + ".")

        if int(hp) <= 0:
            typewriter(name_color() + " defeated the " + enemy + "!")
            fight = False
            gold += go
            typewriter("You've found " + str(go) + " gold!")
            if endgame:
                if enemy == "Goblin":
                    achievements['Slayer'][0]['Required'] += 1
                    if achievements['Slayer'][0]['Required'] >= achievements['Slayer'][0]['Goal']:
                        if job != "Shaman":
                            ATK *= achievements['Slayer'][0]['ATK Increase']
                            achievements['Slayer'][0]['Required'] = achievements['Slayer'][0]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']
                        else:
                            TATK *= achievements['Slayer'][0]['ATK Increase']
                            achievements['Slayer'][0]['Required'] = achievements['Slayer'][0]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']
                elif enemy == "Orc":
                    achievements['Slayer'][1]['Required'] += 1
                    if achievements['Slayer'][1]['Required'] >= achievements['Slayer'][1]['Goal']:
                        if job != "Shaman":
                            ATK *= achievements['Slayer'][1]['ATK2 Increase']
                            achievements['Slayer'][1]['Required'] = achievements['Slayer'][1]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']
                        else:
                            TATK *= achievements['Slayer'][1]['ATK2 Increase']
                            achievements['Slayer'][1]['Required'] = achievements['Slayer'][1]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']
                elif enemy == "Slime":
                    achievements['Slayer'][2]['Required'] += 1
                    if achievements['Slayer'][2]['Required'] >= achievements['Slayer'][2]['Goal']:
                        if job != "Shaman":
                            ATK *= achievements['Slayer'][2]['ATK3 Increase']
                            achievements['Slayer'][2]['Required'] = achievements['Slayer'][2]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']
                        else:
                            TATK *= achievements['Slayer'][2]['ATK3 Increase']
                            achievements['Slayer'][2]['Required'] = achievements['Slayer'][2]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']
                elif enemy == "Harpy":
                    achievements['Slayer'][3]['Required'] += 1
                    if achievements['Slayer'][3]['Required'] >= achievements['Slayer'][3]['Goal']:
                        if job != "Shaman":
                            ATK *= achievements['Slayer'][3]['ATK4 Increase']
                            achievements['Slayer'][3]['Required'] = achievements['Slayer'][3]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']
                        else:
                            TATK *= achievements['Slayer'][3]['ATK4 Increase']
                            achievements['Slayer'][3]['Required'] = achievements['Slayer'][3]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']
                elif enemy == "Minotaur":
                    achievements['Slayer'][4]['Required'] += 1
                    if achievements['Slayer'][4]['Required'] >= achievements['Slayer'][4]['Goal']:
                        if job != "Shaman":
                            ATK *= achievements['Slayer'][4]['ATK5 Increase']
                            achievements['Slayer'][4]['Required'] = achievements['Slayer'][4]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']
                        else:
                            TATK *= achievements['Slayer'][4]['ATK5 Increase']
                            achievements['Slayer'][4]['Required'] = achievements['Slayer'][4]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']
                elif enemy == "Dragon's Mate":
                    achievements['Slayer'][5]['Required'] += 1
                    if achievements['Slayer'][5]['Required'] >= achievements['Slayer'][5]['Goal']:
                        if job != "Shaman":
                            ATK *= achievements['Slayer'][5]['ATK6 Increase']
                            achievements['Slayer'][5]['Required'] = achievements['Slayer'][5]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']
                        else:
                            TATK *= achievements['Slayer'][5]['ATK6 Increase']
                            achievements['Slayer'][5]['Required'] = achievements['Slayer'][5]['Goal']
                            achievements['Meta'][1]['Required'] += 1
                            if achievements['Meta'][1]['Required'] >= achievements['Meta'][1]['Goal']:
                                achievements['Meta'][1]['Required'] = achievements['Meta'][1]['Goal']

        if quest_enemy < 2:
            quest_enemy += 1
        if quest_enemy == 2:
            completed_quest = True
        elif quest_goblins < 4:
            quest_goblins += 1
        if quest_goblins == 4:
            completed_quest = True
        elif quest_orcs < 2:
            quest_orcs += 1
        if quest_orcs == 2:
            completed_quest = True
        elif quest_slimes < 4:
            quest_slimes += 1
        if quest_slimes == 4:
            completed_quest = True
        elif quest_harpies < 2:
            quest_harpies += 1
        if quest_harpies == 4:
            completed_quest = True
        elif quest_minotaurs == 1:
            if random.randint(0, 100) < 30:
                completed_quest = True
        elif keymaterial:
            if random.randint(0, 100) < 30:
                completed_quest = True

        elif boss:
            boss = False
            endgame = True
            typewriter("Congratulations, you've finished the game! Achievements are now unlocked!")
            typewriter("You've also gained a talent for completing your first achievement!")
            typewriter("The achievement tab will show you what achievements you're missing... ")
            typewriter("...as well as the talent the achievements will increase!")
            typewriter("Press Enter to continue!")
            input(">")
            draw()
        if completed_quest:
            level += 1
        gold += 100
        typewriter("You've completed your quest and increased your level to " + level_color() + "!")
        typewriter("You received 100 gold for your troubles!")
        typewriter("Go back to the mayor to continue!")

        if not boss:
            draw()


def shop(buy):
    global gold, pot, elix, job, TATK, level, ATK, HPMAX, MPMAX, keymaterial, completed_quest
    while buy:
        clear()
        draw()
        typewriter("Welcome to the shop!")
        draw()
        typewriter(f"GOLD: " + gold_color())
        typewriter(f"POTIONS: {pot}")
        typewriter(f"ELIXIRS: {elix}")
        if job == "Shaman":
            typewriter(f"TOTEM ATK: " + TATK_color())
        else:
            typewriter(f"ATK: " + ATK_color())
        typewriter(f"MAXHP: " + HPMAX_color())
        typewriter(f"MAXMP: " + MPMAX_color())
        draw()
        typewriter(f"1 - BUY POTION ({20 * level}HP) - 5 GOLD")
        typewriter(f"2 - BUY ELIXIR ({20 * level}MP) - 5 GOLD")
        if job == "Shaman":
            typewriter(f"3 - UPGRADE WEAPON (+{2 * level}TOTEM ATK) - 10 GOLD")
        else:
            typewriter(f"3 - UPGRADE WEAPON (+{2 * level}ATK) - 10 GOLD")
        typewriter(f"4 - UPGRADE ARMOR (+{2 * level}HP) - 10 GOLD")
        typewriter(f"5 - UPGRADE TRINKETS (+{2 * level}MP) - 10 GOLD")
        if keymaterial:
            typewriter("6 - BUY MATERIAL (INSTANT LEVEL-UP) - 100 GOLD")
            typewriter("7 - LEAVE")
        else:
            typewriter("6 - LEAVE")
        draw()
        choice_shop = input("> ")
        draw()

        if choice_shop == "1":
            if gold >= 5:
                pot += 1
                gold -= 5
                typewriter("You've bought a potion!")
                if endgame:
                    achievements['Shopping'][1]['Required'] += 1
                    if achievements['Shopping'][1]['Required'] >= achievements['Shopping'][1]['Goal']:
                        MPMAX *= achievements['Shopping'][1]['MAXMP2 Increase']
                        achievements['Shopping'][1]['Required'] = achievements['Shopping'][1]['Goal']
                        achievements['Meta'][2]['Required'] += 1
                        if achievements['Meta'][2]['Required'] >= achievements['Meta'][2]['Goal']:
                            achievements['Meta'][2]['Required'] = achievements['Meta'][2]['Goal']
            else:
                typewriter("Not enough gold!")
        elif choice_shop == "2":
            if gold >= 5:
                elix += 1
                gold -= 5
                typewriter("You've bought an elixir!")
                if endgame:
                    achievements['Shopping'][0]['Required'] += 1
                    if achievements['Shopping'][0]['Required'] >= achievements['Shopping'][0]['Goal']:
                        MPMAX *= achievements['Shopping'][0]['MAXMP1 Increase']
                        achievements['Shopping'][0]['Required'] = achievements['Shopping'][0]['Goal']
                        achievements['Meta'][2]['Required'] += 1
                        if achievements['Meta'][2]['Required'] >= achievements['Meta'][2]['Goal']:
                            achievements['Meta'][2]['Required'] = achievements['Meta'][2]['Goal']
            else:
                typewriter("Not enough gold!")
        elif choice_shop == "3":
            if gold >= 10:
                if job == "Shaman":
                    TATK += 2 * level
                else:
                    ATK += 2 * level
                    gold -= 10
                    typewriter("Weapon upgraded!")
                    if endgame:
                        achievements['Shopping'][2]['Required'] += 1
                        if achievements['Shopping'][2]['Required'] >= achievements['Shopping'][2]['Goal']:
                            MPMAX *= achievements['Shopping'][2]['MAXMP1 Increase']
                            achievements['Shopping'][2]['Required'] = achievements['Shopping'][2]['Goal']
                            achievements['Meta'][2]['Required'] += 1
                            if achievements['Meta'][2]['Required'] >= achievements['Meta'][2]['Goal']:
                                achievements['Meta'][2]['Required'] = achievements['Meta'][2]['Goal']
            else:
                typewriter("Not enough gold!")
        elif choice_shop == "4":
            if gold >= 10:
                HPMAX += 2 * level
                gold -= 10
                typewriter("Armor upgraded!")
                if endgame:
                    achievements['Shopping'][3]['Required'] += 1
                    if achievements['Shopping'][3]['Required'] >= achievements['Shopping'][3]['Goal']:
                        MPMAX *= achievements['Shopping'][3]['MAXMP1 Increase']
                        achievements['Shopping'][3]['Required'] = achievements['Shopping'][3]['Goal']
                        achievements['Meta'][2]['Required'] += 1
                        if achievements['Meta'][2]['Required'] >= achievements['Meta'][2]['Goal']:
                            achievements['Meta'][2]['Required'] = achievements['Meta'][2]['Goal']
            else:
                typewriter("Not enough gold!")
        elif choice_shop == "5":
            if gold >= 10:
                MPMAX += 2 * level
                gold -= 10
                typewriter("Trinkets upgraded!")
                if endgame:
                    achievements['Shopping'][4]['Required'] += 1
                    if achievements['Shopping'][4]['Required'] >= achievements['Shopping'][4]['Goal']:
                        MPMAX *= achievements['Shopping'][4]['MAXMP1 Increase']
                        achievements['Shopping'][4]['Required'] = achievements['Shopping'][4]['Goal']
                        achievements['Meta'][2]['Required'] += 1
                        if achievements['Meta'][2]['Required'] >= achievements['Meta'][2]['Goal']:
                            achievements['Meta'][2]['Required'] = achievements['Meta'][2]['Goal']
            else:
                typewriter("Not enough gold!")
        elif choice_shop == "6" and keymaterial:
            if gold >= 100:
                completed_quest = True
                gold -= 100
                typewriter("Material bought!")
            else:
                typewriter("Not enough gold!")
        elif choice_shop == "6" or choice_shop == "7":
            buy = False
        else:
            typewriter("Invalid input!")


def mayor():
    global map, biom, y_len, x_len, name, quest_minotaurs, quest_goblins, quest_slimes, quest_harpies, \
        quest_orcs, quest_enemy, keymaterial, keymold, keyenchant, pot, elix, completed_quest
    clear()
    draw()

    typewriter("Mayor: Hello there, " + name_color() + "!")

    quest_texts = [("Mayor: I hear you're looking for adventure!",
                    "Mayor: How about you go out and kill an enemy for us? Any will do!", "You now have a quest!"),
                   ("Mayor: You've done well! Here's some gold for your troubles. Now, let's get down to business.",
                    "Mayor: You see, we are besieged by so many creatures. The biggest nuisance being the Goblins.",
                    "Mayor: If you can clear out 4 Goblins, we would be grateful.", "You now have a new quest!"),
                   (
                   "Mayor: Amazing! You surprised me!", "Mayor: Now that the Goblins are gone, the next issue is Orcs.",
                   "Mayor: Please clear out 2 Orcs for us!", "Mayor: You're doing so well! Keep it up!",
                   "Mayor: I was going to send you after Harpies next, but Slimes have started getting out of hand!",
                   "Mayor: Please clear out 4 Slimes for us!"),
                   ("Mayor: Thank goodness you've defeated those dastardly Slimes!",
                    "Mayor: Now, let's move on to Harpies. They are stealing our grain and must be stopped!",
                    "Mayor: Please defeat 2 Harpies for us!"),
                   ("Mayor: Now you're experienced with the kind of monsters we are facing.",
                    "Mayor: They're all led by the evil dragon that lurks inside his cave.",
                    "Mayor: Unfortunately, this cave is protected by a magical door.", "Mayor: An enchanted key is "
                                                                                       "necessary to open it.",
                    "Mayor: First, we must mold the key.",
                    "Mayor: Go east until you reach the cave, and use this putty to make a key."),
                   ("Mayor: Perfect, you've got the key mold!", "Mayor: Now to get the key material.",
                    "You can buy one from the shop to the southeast, or you can possibly find one on an enemy.",
                    "Mayor: Perfect! You have the material!", "Mayor: Give my blacksmiths a little while to craft the "
                                                              "key.",
                    "Mayor: In the meantime, I want you to buy the materials to enchant the key.",
                    "Mayor: Bring me 10 elixirs and 10 potions. That should provide enough magical energy."),
                   ("Mayor: We're so close to ridding ourselves of that terrible dragon!",
                    "Mayor: The final step is to enchant the key",
                    "Mayor: Luckily, the dragon made a mistake as we got closer.",
                    "Mayor: He sent Minotaurs after us!",
                    "Mayor: Minotaurs are his top lieutenants, but killing them is the way to enchanting the key.",
                    "Mayor: Kill Minotaurs until you've unlocked the magic!"),
                   ("Mayor: It is time to take on the dragon!",
                    "Mayor: Take the finished key with you, but be careful with the beast!",
                    "Your final quest awaits! Find the Cave and take on the Dragon!")]

    if quest_enemy == 0:
        for text in quest_texts[0]:
            typewriter(text)
    elif quest_goblins < 4:
        for text in quest_texts[1]:
            typewriter(text)
    elif quest_orcs < 2:
        for text in quest_texts[2]:
            typewriter(text)
    elif quest_slimes < 4:
        for text in quest_texts[3]:
            typewriter(text)
    elif quest_harpies < 2:
        for text in quest_texts[4]:
            typewriter(text)
    elif quest_harpies == 2:
        for text in quest_texts[5]:
            typewriter(text)
    elif keymold == 1 and keymaterial == 1 and keyenchant == 0:
        if elix < 10:
            typewriter("You don't have enough elixirs!")
        elif pot < 10:
            typewriter("You don't have enough potions!")
        else:
            for text in quest_texts[6]:
                typewriter(text)
            pot -= 10
            elix -= 10
            completed_quest = True
            keyenchant += 1
    elif keyenchant == 1:
        for text in quest_texts[7]:
            typewriter(text)
    elif quest_minotaurs == 1:
        for text in quest_texts[8]:
            typewriter(text)


def cave():
    global map, biom, y_len, x_len, keymold, quest_minotaurs, fight
    draw()
    typewriter("Here lies the door to the lair of the dragon. What will you do?")
    if keymold == 1:
        typewriter("1 - MAKE KEY MOLD")
    if quest_minotaurs == 1:
        typewriter("1 - USE FINISHED KEY")
    typewriter("2 - TURN BACK")
    draw()
    choice_cave = input("> ")
    clear()
    if choice_cave == "1":
        if keymold == 1:
            typewriter("You walk up to the door and make the mold. Time to return to the Mayor.")
            typewriter("Congratulations! You finished the quest and increased your level to " + level_color() + "!")
            level += 1
            keymold += 1
        if quest_minotaurs == 2:
            clear()
            fight = True
            battle()
    elif choice_cave == "2":
        clear()


def new_game():
    global name, job, ability, HPMAX, MPMAX, ATK, HP, MP, TATK
    with open("blacklist.txt", "r") as f:
        blacklist = f.read().splitlines()
        typewriter("To start, what is your name?")
        name = input("> ")
        while name in blacklist:
            typewriter("That name is not allowed.")
            typewriter("Please enter a different name.")
            name = input("> ")
        if name not in blacklist:
            job_options = [
                ("Warrior", "Berserk", 45, 25, 3, 0),
                ("Rogue", "Sneak Attack", 25, 25, 5, 0),
                ("Mage", "Fireball", 25, 45, 3, 0),
                ("Warlock", "Life Leech", 35, 35, 4, 0),
                ("Shaman", "Summon Totem", 35, 45, 0, 1)]
            typewriter(f"Perfect! Welcome, " + name_color() + "!")
            typewriter("Now to pick a job:")
            for i, (job, ability, HP, MP, ATK, TATK) in enumerate(job_options):
                typewriter(str(i + 1) + "-" + job_color() + ": " + ability_color() + ","
                f" HP: " + HP_color() + ", MP: " + MP_color() + ", ATK: " + ATK_color() + ","
                f" TATK: " + TATK_color() + "")
            typewriter("What will your job be?")
            job_choice = int(input("> ")) - 1
            job, ability, HPMAX, MPMAX, ATK, TATK = job_options[job_choice]
            HP = HPMAX
            MP = MPMAX

            typewriter(f"Perfect! Your job is " + job_color() + "! Your ability is " + ability_color() + "!")
            typewriter(f"Your HP is " + HP_color() + " and your MP is " + MP_color() + "!")
            typewriter("Now, let's start your adventure!")
            play()


def h2p():
    clear()
    typewriter("How to Play:")
    typewriter("This game is about doing quests to level to 10 so you can defeat the Dragon!")
    typewriter("Each quest completed will increase your level by 1")
    typewriter("Use the number keys to change between menus and move around the map.")
    typewriter("You can press 0 at any time to save and return to the main menu.")
    typewriter("Continue? (y/n)")
    cont1 = input("> ").lower()
    if cont1 == "y":
        typewriter("You can choose from 4 jobs. Each job starts with a unique ability.")
        typewriter("Warrior - Berserk: Attacks twice.")
        typewriter("Rogue - Sneak Attack: Deals massive damage based on ATK in the first round of each fight.")
        typewriter("Mage - Fireball: Deals damage based on MP")
        typewriter("Warlock - Life Leech: Restores health based on damage output")
        typewriter("Shaman - Summon Totem: Summons Totems that deal Damage Over Time.")
        typewriter("Continue? (y/n)")
        cont2 = input("> ").lower()
        if cont2 == "y":
            typewriter("You will start in a Town. Going east will take you to the mayor's house.")
            typewriter("This is where you can pick up quests.")
            typewriter("You can also visit the shop in the southern part of town to upgrade your gear.")
            typewriter("You need to kill enemies in the wilderness to get the gold for upgrades.")
            typewriter("Going south of the shop or east of the Mayor's house will take you to the bridge.")
            typewriter("This bridge will lead you to the wilderness where you can encounter enemies.")
            typewriter("Continue? (y/n)")
            cont3 = input("> ").lower()
            if cont3 == "y":
                typewriter("Once you've finished the main story, you will unlock achievements.")
                typewriter("You will no longer gain levels, however you WILL gain something new: talents!")
                typewriter("The talent you get is based on the achievement type.")
                typewriter("For example: 'slayer' achievements give bonus ATK and 'shop' achievements give bonus MP")
                typewriter("Collect all the achievements and send me a screenshot to be added to the Hall of Fame!")
                typewriter("The Hall of Fame can be found on the GitHub page and in the ReadMe. Now go enjoy yourself!")
                typewriter("Would you like a few tips on completing the game? (y/n)")
                cont4 = input("> ").lower()
                if cont4 == "y":
                    typewriter("Warriors will start slow, but can be helped if you upgrade their weapons.")
                    typewriter("Warlocks' Life Leech damage/healing are based on MAXHP, so upgrade your armor!")
                    typewriter("Mages will literally 1-shot everything, including the Dragon...")
                    typewriter("Rogues will also 1-shot everything at first, but will get harder as you go.")
                    typewriter("Shamans are special in that they rely on stacking totems in order to deal"
                               " damage over time.")
                    typewriter("Press 1 when you're ready to go back to the main menu.")
                    back_to_menu = input("> ")
                    if back_to_menu == "1":
                        main_menu()
                        clear()
                    else:
                        typewriter("You're not very good at following directions,are you?")
                        main_menu()
                        clear()
                elif cont4 == "n":
                    main_menu()
                    clear()
            elif cont3 == "n":
                main_menu()
                clear()
        elif cont2 == "n":
            main_menu()
            clear()
    elif cont1 == "n":
        main_menu()
        clear()


def play():
    global standing, x, y, map, biom, endgame, fight
    while run:
        if not standing and biom[map[y][x]]["e"] and random.randint(0, 10) > 3:
            clear()
            fight = True
            battle()
        else:
            clear()
            display_location()
            display_stats()
            display_options()
            dest = input("> ")
            handle_destination(dest)


def display_location():
    typewriter("LOCATION: " + biom[map[y][x]]["t"])
    draw()


def display_stats():
    typewriter("NAME: " + name_color())
    typewriter("JOB: " + job_color())
    typewriter("LEVEL: " + level_color())
    typewriter("HP: " + HP_color() + "/" + HPMAX_color())
    typewriter("MP: " + MP_color() + "/" + MPMAX_color())
    if job == "Shaman":
        typewriter("TOTEM ATK:" + TATK_color())
    else:
        typewriter("ATK: " + ATK_color())
    typewriter("POTIONS: " + str(pot))
    typewriter("ELIXIRS: " + str(elix))
    typewriter("GOLD: " + gold_color())
    typewriter("COORD: " + x_color() + "," + y_color())
    if endgame:
        if len(tracked) > 0:
            typewriter("Tracked achievements: " + str(tracked))


def display_options():
    draw()
    typewriter("0 - SAVE AND QUIT")
    typewriter("1 - MAP")
    if y > 0:
        typewriter("2 - NORTH")
    if x < x_len:
        typewriter("3 - EAST")
    if y < y_len:
        typewriter("4 - SOUTH")
    if x > 0:
        typewriter("5 - WEST")
    if pot > 0:
        typewriter("6 - USE POTION (" + str(20 * level) + "HP)")
    if elix > 0:
        typewriter("7 - USE ELIXIR (" + str(20 * level) + "MP)")
    if map[y][x] == "shop" or map[y][x] == "mayor" or map[y][x] == "cave":
        typewriter("8 - ENTER")
    if endgame:
        typewriter("9 - ACHIEVEMENTS LIST")
    draw()


def handle_destination(dest):
    global pot, elix, standing, map, x, y, endgame

    def move(x_offset, y_offset):
        global standing, map, x, y
        x += x_offset
        y += y_offset
        clear()
        standing = False

    if dest == "0":
        save_game()
        exit()
    elif dest == "1":
        clear()
        map_menu()
    elif dest == "2" and y > 0:
        move(0, -1)
    elif dest == "3" and x < x_len:
        move(1, 0)
    elif dest == "4" and y < y_len:
        move(0, 1)
    elif dest == "5" and x > 0:
        move(-1, 0)
    elif dest == "6":
        heal_mana(20, pot, "potion")
        standing = True
    elif dest == "7":
        heal_mana(20, elix, "elixir")
        standing = True
    elif dest == "8":
        if map[y][x] == "shop":
            clear()
            shop(buy=True)
        if map[y][x] == "mayor":
            clear()
            mayor()
        if map[y][x] == "cave":
            clear()
            cave()
    elif dest == "9":
        if endgame:
            print_achievements()
        else:
            typewriter("You do not have achievements unlocked!")

    if endgame:
        # Check if the player has entered a new biome
        if map[y][x] == "plains":
            achievements['Exploration'][0]['Required'] += 1
            if achievements['Exploration'][0]['Required'] >= achievements['Exploration'][0]['Goal']:
                HPMAX *= achievements['Exploration'][0]['MAXHP1 Increase']
                achievements['Exploration'][0]['Required'] = achievements['Exploration'][0]['Goal']
                achievements['Meta'][0]['Required'] += 1
                if achievements['Meta'][0]['Required'] >= achievements['Meta'][0]['Goal']:
                    achievements['Meta'][0]['Required'] = achievements['Meta'][0]['Goal']
        elif map[y][x] == "woods":
            achievements['Exploration'][1]['Required'] += 1
            if achievements['Exploration'][1]['Required'] >= achievements['Exploration'][1]['Goal']:
                HPMAX *= achievements['Exploration'][1]['MAXHP2 Increase']
                achievements['Exploration'][1]['Required'] = achievements['Exploration'][1]['Goal']
                achievements['Meta'][0]['Required'] += 1
                if achievements['Meta'][0]['Required'] >= achievements['Meta'][0]['Goal']:
                    achievements['Meta'][0]['Required'] = achievements['Meta'][0]['Goal']
        elif map[y][x] == "fields":
            achievements['Exploration'][2]['Required'] += 1
            if achievements['Exploration'][2]['Required'] >= achievements['Exploration'][2]['Goal']:
                HPMAX *= achievements['Exploration'][2]['MAXHP3 Increase']
                achievements['Exploration'][2]['Required'] = achievements['Exploration'][2]['Goal']
                achievements['Meta'][0]['Required'] += 1
                if achievements['Meta'][0]['Required'] >= achievements['Meta'][0]['Goal']:
                    achievements['Meta'][0]['Required'] = achievements['Meta'][0]['Goal']
        elif map[y][x] == "mountain":
            achievements['Exploration'][3]['Required'] += 1
            if achievements['Exploration'][3]['Required'] >= achievements['Exploration'][3]['Goal']:
                HPMAX *= achievements['Exploration'][3]['MAXHP4 Increase']
                achievements['Exploration'][3]['Required'] = achievements['Exploration'][3]['Goal']
                achievements['Meta'][0]['Required'] += 1
                if achievements['Meta'][0]['Required'] >= achievements['Meta'][0]['Goal']:
                    achievements['Meta'][0]['Required'] = achievements['Meta'][0]['Goal']
        elif map[y][x] == "hills":
            achievements['Exploration'][4]['Required'] += 1
            if achievements['Exploration'][4]['Required'] >= achievements['Exploration'][4]['Goal']:
                HPMAX *= achievements['Exploration'][4]['MAXHP5 Increase']
                achievements['Exploration'][4]['Required'] = achievements['Exploration'][4]['Goal']
                achievements['Meta'][0]['Required'] += 1
                if achievements['Meta'][0]['Required'] >= achievements['Meta'][0]['Goal']:
                    achievements['Meta'][0]['Required'] = achievements['Meta'][0]['Goal']
        elif map[y][x] == "bridge":
            achievements['Exploration'][5]['Required'] += 1
            if achievements['Exploration'][5]['Required'] >= achievements['Exploration'][5]['Goal']:
                HPMAX *= achievements['Exploration'][5]['MAXHP6 Increase']
                achievements['Exploration'][5]['Required'] = achievements['Exploration'][5]['Goal']
                achievements['Meta'][0]['Required'] += 1
                if achievements['Meta'][0]['Required'] >= achievements['Meta'][0]['Goal']:
                    achievements['Meta'][0]['Required'] = achievements['Meta'][0]['Goal']


def main_menu():
    typewriter("This is V2.2 of my text-based RPG!")
    typewriter("I have now added achievements, talents, and colored text!")
    typewriter("Would you like to load a saved game? (y/n)")
    load_option = input("> ").lower()
    if load_option == "y":
        load_game()
    if load_option == "n":
        typewriter("OK, we'll start a new game! But first, would you like instructions on how to play (y/n)?")
        instruct = input("> ").lower()
        if instruct == "y":
            h2p()
        if instruct == "n":
            typewriter("OK! Let's get into it!!")
            new_game()


while run:
    clear()
    main_menu()
